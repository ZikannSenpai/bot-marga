const { downloadContentFromMessage } = require("@whiskeysockets/baileys");

module.exports = async (sock, msg, args) => {
    try {
        const from = msg.key.remoteJid;
        let quoted = msg.quoted;

        if (!quoted) {
            return sock.sendMessages(
                from,
                {
                    text: "Reply photo view once firts!"
                },
                { quoted: msg }
            );
        }

        if (quoted.viewOnceMessageV2) quoted = quoted.viewOnceMessageV2.message;
        if (quoted.viewOnceMessage) quoted = quoted.viewOnceMessage.message;

        const mediaMsg =
            quoted.imageMessage || quoted.videoMessage || quoted.audioMessage;

        if (!mediaMsg) {
            return sock.sendMessages(
                from,
                {
                    text: "That is not view-once message"
                },
                { quoted: msg }
            );
        }

        const mime = mediaMsg.mimetype || "";
        const mediaType = /image/.test(mime)
            ? "image"
            : /video/.test(mime)
            ? "video"
            : "audio";

        const stream = await downloadContentFromMessage(mediaMsg, mediaType);
        let buffer = Buffer.from([]);
        for await (const chunk of stream) {
            buffer = Buffer.concat([buffer, chunk]);
        }

        if (/image/.test(mime)) {
            await sock.sendMessages(
                from,
                {
                    image: buffer,
                    caption: mediaMsg.caption || ""
                },
                { quoted: msg }
            );
        } else if (/video/.test(mime)) {
            await sock.sendMessages(
                from,
                {
                    video: buffer,
                    caption: mediaMsg.caption || ""
                },
                { quoted: msg }
            );
        } else if (/audio/.test(mime)) {
            await sock.sendMessage(
                from,
                { audio: buffer, mimetype: "audio/mpeg", ptt: true },
                { quoted: msg }
            );
        }
    } catch (err) {
        console.error("Error:", err);
        await sock.sendMessage(from, {
          text: "cant open view-once!"
    }, {quoted: msg})
}
}